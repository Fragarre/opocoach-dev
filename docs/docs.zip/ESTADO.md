# ESTADO DEL PROYECTO

**Versión:** 1.0

---

# Estado general

## Módulos finalizados

| Módulo | Estado |
|---------|--------|
| Gestión de convocatorias | ✔ |
| Gestión del temario | ✔ |
| Importación del corpus documental | ✔ |
| Fragmentación de documentos | ✔ |
| Indexación | ✔ |
| Generación de preguntas mediante IA | ✔ |
| Refinamiento de preguntas | ✔ |
| Validación de preguntas | ✔ |
| Clasificación de preguntas | ✔ |
| Importación de exámenes oficiales | ✔ |
| Banco de preguntas | ✔ |
| Generación de simulacros | ✔ |
| Corrección automática | ✔ |
| Informe personalizado mediante IA | ✔ |
| Exportación PDF | ✔ |

---

# En desarrollo

- Documentación del proyecto.

---

# Pendiente

## Mantenimiento

- Importación idempotente de documentos.
- Importación idempotente de preguntas.
- Importación idempotente de exámenes.
- Eliminación de duplicados.
- Mantenimiento del banco de preguntas.
- Revalidación del banco tras cambios en el temario.
- Auditorías de consistencia.

## Importación de preguntas

- Importación automática desde exámenes en PDF.

## Entrenamiento

- Tests personalizados.
- Estadísticas de aprendizaje.
- Seguimiento del opositor.

## Tutor

- Tutor especializado en la convocatoria.

---

# Situación actual

La arquitectura principal del sistema está completada.

Las siguientes fases se centran en:

- herramientas de mantenimiento;
- automatización de procesos;
- ampliación de funcionalidades para el opositor.

No se prevén cambios estructurales importantes en la arquitectura del proyecto.