# OpoCoach

**Versión:** 0.2

**Documento:** Estructura del proyecto

---

# 1. Objetivo

Definir la organización física del proyecto y la finalidad de cada directorio.

---

# 2. Estructura

```
OpoCoach/
│
├── config/
├── core/
├── data/
├── db/
├── docs/
├── importaciones/
├── procesos/
├── prompts/
├── render/
├── tests/
└── ...
```

---

# 3. Directorios

| Directorio | Descripción |
|------------|-------------|
| config | Configuración de convocatorias, normas y parámetros generales. |
| core | Módulos reutilizables utilizados por el resto de la aplicación. |
| data | Documentación oficial del temario organizada por convocatorias. |
| db | Base de datos SQLite y scripts relacionados. |
| docs | Documentación técnica y funcional del proyecto. |
| importaciones | Archivos temporales, JSON extraídos e informes de incidencias. |
| procesos | Procesos ejecutables que construyen y actualizan la base de datos. |
| prompts | Prompts utilizados por los distintos procesos de IA. |
| render | Simulacros y documentos generados (PDF, HTML, etc.). |
| tests | Scripts y datos de prueba. |

---

# 4. Reglas de organización

- Cada directorio tiene una única responsabilidad.
- Los módulos reutilizables se ubican en `core`.
- Los procesos ejecutables se ubican en `procesos`.
- La configuración se centraliza en `config`.
- Toda la documentación reside en `docs`.
- Los archivos temporales nunca se almacenan fuera de `importaciones`.
- Todas las convocatorias utilizan la misma estructura.

---

# 5. Incorporación de nuevos componentes

Los nuevos módulos deberán integrarse en la estructura existente.

Solo se crearán nuevos directorios cuando la funcionalidad no pueda ubicarse razonablemente en alguno de los ya existentes.

La arquitectura deberá mantenerse estable y homogénea para todas las convocatorias.