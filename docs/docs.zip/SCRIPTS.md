# OpoCoach

**Versión:** 1.0

**Documento:** Inventario de scripts

**Última revisión:** 2026-07-14

---

# CORE

Módulos reutilizables utilizados por el resto de la aplicación.

| Script | Función | BD | Estado |
|---------|----------|----|--------|
| normas.py | Gestión y detección de normas | No | OK |
| temario.py | Gestión del temario | No | OK |
| selector_banco.py | Selección de preguntas del banco | No | OK |
| huellas.py | Detección de preguntas duplicadas | No | OK |
| buscar_fragmentos.py | Recuperación semántica de fragmentos | No | OK |
| ... | ... | ... | ... |

---

# PROCESOS

Procesos ejecutables que construyen o actualizan la base de datos.

| Script | Función | BD | Estado |
|---------|----------|----|--------|
| importar_documentos.py | Importación del temario | Sí | OK |
| fragmentar_documentos.py | Fragmentación documental | Sí | OK |
| construir_indice.py | Construcción del índice | Sí | OK |
| importar_json_extraido.py | Incorporación de preguntas al banco | Sí | OK |
| clasificar_tipo_pregunta.py | Clasificación teoría/práctica | Sí | OK |
| generar_simulacro.py | Generación de simulacros | Sí | OK |
| ... | ... | ... | ... |

---

# UTILIDADES

Scripts auxiliares.

| Script | Función | Estado |
|---------|----------|--------|
| ... | ... | ... |

---

# ESTADOS

| Estado | Significado |
|---------|-------------|
| OK | Finalizado y estable |
| REV | En revisión |
| DES | En desarrollo |
| OBS | Obsoleto |