# OpoCoach

**Versión:** 0.2

**Documento:** Verificación del proyecto

---

# 1. Objetivo

Verificar que el proyecto está correctamente instalado, configurado y preparado para trabajar con una convocatoria.

La verificación debe poder ejecutarse en cualquier momento y no modifica ningún dato del proyecto.

---

# 2. Base de datos

Debe comprobarse:

- Existe la base de datos.
- Es accesible.
- Contiene las tablas obligatorias.
- Puede abrirse una conexión SQLite.
- Puede realizarse una consulta simple.

Estado:

- OK
- ERROR

---

# 3. Convocatorias

Para cada convocatoria existente:

- Existe el fichero CFG.
- El CFG puede cargarse.
- Todos los documentos definidos existen.
- Todos los temas son válidos.
- Todas las partes existen.

Estado:

- OK
- AVISO
- ERROR

---

# 4. Documentación

Debe comprobarse:

- Existe la carpeta docs.
- Existe README.md.
- Existe 00_FUNCIONALIDAD.md.
- Existe 01_ESTRUCTURA_PROYECTO.md.
- Existe 02_CONVENCIONES.md.
- Existe 03_ARQUITECTURA_BD.md.
- Existe 04_SCRIPTS.md.
- Existe 05_ESTADO.md.
- Existe 06_HISTORIAL_VERSIONES.md.
- No existen cabeceras pendientes.

Estado:

- OK
- AVISO

---

# 5. Scripts

Debe comprobarse:

- Todos los scripts tienen cabecera.
- No existen errores de sintaxis.
- El inventario está generado.

Estado:

- OK
- AVISO
- ERROR

---

# 6. Documentos

Debe comprobarse:

- Existen todos los documentos del temario.
- Todos pueden abrirse.
- Todos tienen tamaño mayor que cero.

Estado:

- OK
- ERROR

---

# 7. Fragmentación

Debe comprobarse:

- Existen fragmentos.
- Existe el índice BM25.
- Existen relaciones documento-fragmento.

Estado:

- OK
- ERROR

---

# 8. Inteligencia Artificial

Debe comprobarse:

- API Key configurada.
- Modelo configurado.
- Puede realizarse una llamada de prueba opcional.

Estado:

- OK
- AVISO
- ERROR

---

# 9. Directorios

Debe comprobarse la existencia de:

- config
- core
- procesos
- docs
- data
- logs
- salida

Estado:

- OK
- AVISO

---

# 10. Dependencias

Debe comprobarse la disponibilidad de las librerías utilizadas por el proyecto.

Estado:

- OK
- ERROR

---

# 11. Resultado final

Cada comprobación devolverá uno de los siguientes estados:

- OK
- AVISO
- ERROR

El proyecto solo se considerará operativo cuando no exista ningún ERROR.

Los AVISOS no impiden el funcionamiento, pero deberán revisarse.

---

# 12. Salida estándar

La salida del proceso tendrá el siguiente formato:

```
======================================================================
VERIFICACIÓN DEL PROYECTO
======================================================================

Base de datos.................... OK
Convocatorias.................... OK
Documentación.................... OK
Scripts.......................... OK
Documentos....................... OK
Fragmentación.................... OK
Inteligencia Artificial.......... OK
Directorios...................... OK
Dependencias..................... OK

----------------------------------------------------------------------
ERRORES : 0
AVISOS  : 0

PROYECTO OPERATIVO
======================================================================
```