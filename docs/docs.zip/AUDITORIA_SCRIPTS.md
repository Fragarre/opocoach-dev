# OpoCoach

**Documento:** Auditoría de scripts

## Resumen

| Estado | Cantidad |
|---|---:|
| REVISAR | 0 |
| PROCESO_MANUAL | 15 |
| ACTIVO | 21 |
| INFRAESTRUCTURA | 1 |
| Total | 37 |

## REVISAR

Ninguno.

## PROCESO_MANUAL

### `procesos/actualizar_documentos.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.actualizar_documentos`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza:
  - `core.temario`
- Funciones:
  - `actualizar_documento()`
  - `actualizar_documentos_temas()`
  - `calcular_hash()`
  - `cargar_documentos_cfg()`
  - `conectar()`
  - `crear_argumentos()`
  - `dividir_bloques()`
  - `eliminar_duplicados()`
  - `extraer_pdf()`
  - `fragmentar_articulo()`
  - `generar_fragmentos()`
  - `insertar_documento()`
  - `limpiar_texto()`
  - `localizar_articulos()`
  - `main()`
  - `obtener_documento_bd()`
  - `reemplazar_fragmentos()`
  - `referencia_articulo()`
  - `seleccionar_documentos()`

### `procesos/auditar_scripts.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.auditar_scripts`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza módulos internos: no.
- Funciones:
  - `analizar_script()`
  - `clasificar()`
  - `generar_informe()`
  - `main()`
  - `modulo_desde_ruta()`
  - `obtener_scripts()`
  - `relacionar_dependencias()`
  - `ruta_relativa()`

### `procesos/calcular_distribucion_modelo.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.calcular_distribucion_modelo`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza módulos internos: no.
- Funciones:
  - `main()`

### `procesos/clasificar_modelo.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.clasificar_modelo`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza:
  - `core.clasificador`
  - `core.temario`
- Funciones:
  - `abrir_conexion()`
  - `aplicar_correccion_modelo()`
  - `cargar_opciones()`
  - `cargar_preguntas_modelo()`
  - `crear_argumentos()`
  - `guardar_resultado()`
  - `main()`
  - `mostrar_resultado()`
  - `obtener_parte_origen()`
  - `obtener_tipo_pregunta()`

### `procesos/clasificar_pendientes.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.clasificar_pendientes`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza:
  - `core.clasificador`
  - `core.temario`
- Funciones:
  - `abrir_conexion()`
  - `cargar_opciones()`
  - `cargar_pendientes()`
  - `crear_argumentos()`
  - `guardar_resultado()`
  - `main()`
  - `mostrar_resultado()`

### `procesos/clasificar_pregunta.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.clasificar_pregunta`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza:
  - `core.clasificador`
  - `core.temario`
- Funciones:
  - `abrir_conexion()`
  - `cargar_opciones()`
  - `cargar_pregunta()`
  - `crear_argumentos()`
  - `guardar_resultado()`
  - `main()`
  - `mostrar_pregunta()`
  - `mostrar_resultado()`
  - `validar_pregunta()`

### `procesos/clasificar_tipo_pregunta.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.clasificar_tipo_pregunta`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza módulos internos: no.
- Funciones:
  - `abrir_conexion()`
  - `actualizar_tipo()`
  - `cargar_preguntas()`
  - `clasificar_especial()`
  - `clasificar_tipo()`
  - `contiene_patron()`
  - `crear_argumentos()`
  - `empieza_como_teorica()`
  - `main()`
  - `mostrar_pregunta()`
  - `normalizar_texto()`
  - `puntuacion_practica()`

### `procesos/completar_simulacro_ia.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.completar_simulacro_ia`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza:
  - `core.openai_api`
- Funciones:
  - `abrir_bd()`
  - `buscar_ultimo_simulacro()`
  - `cargar_simulacro()`
  - `completar_simulacro()`
  - `construir_prompt()`
  - `crear_argumentos()`
  - `generar_preguntas()`
  - `main()`
  - `obtener_documentacion()`
  - `obtener_tema()`
  - `preguntas_existentes_tema()`
  - `reconstruir_orden()`
  - `resolver_ruta()`
  - `validar_pregunta()`
  - `validar_totales()`

### `procesos/exportar_simulacro_html.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.exportar_simulacro_html`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza módulos internos: no.
- Funciones:
  - `buscar_simulacro_reciente()`
  - `cargar_simulacro()`
  - `construir_html()`
  - `construir_pregunta()`
  - `construir_soluciones()`
  - `crear_argumentos()`
  - `escapar()`
  - `main()`
  - `nombre_bloque()`

### `procesos/extraer_pdf_imagenes.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.extraer_pdf_imagenes`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza módulos internos: no.
- Funciones:
  - `calcular_ruta_salida()`
  - `crear_argumentos()`
  - `crear_cliente()`
  - `extraer_pdf()`
  - `imagen_a_data_url()`
  - `limpiar_json()`
  - `llamar_vision()`
  - `main()`
  - `renderizar_pagina()`
  - `validar_estructura()`

### `procesos/generar_explicaciones.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.generar_explicaciones`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza:
  - `core.buscar_explicacion`
  - `core.construir_prompt_explicacion`
  - `core.guardar_explicacion`
  - `core.huellas`
  - `core.obtener_fragmento`
  - `core.openai_api`
- Funciones:
  - `enriquecer_simulacro()`
  - `main()`

### `procesos/generar_pdf.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.generar_pdf`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza:
  - `core.normalizar_simulacro`
  - `core.render_pdf`
  - `core.render_soluciones_pdf`
- Funciones:
  - `main()`
  - `ultimo_simulacro_explicado()`

### `procesos/generar_simulacro.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.generar_simulacro`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza:
  - `core.constructor_simulacro`
- Funciones:
  - `crear_nombre_archivo()`
  - `guardar_simulacro()`
  - `main()`
  - `mostrar_resumen()`

### `procesos/importar_json_extraido.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.importar_json_extraido`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza:
  - `core.huellas`
  - `core.normas`
  - `core.temario`
  - `core.validar_pie`
- Funciones:
  - `abrir_conexion()`
  - `calcular_hash_archivo()`
  - `cargar_huellas_existentes()`
  - `cargar_json()`
  - `cargar_opciones_existentes()`
  - `comprobar_pdf_no_importado()`
  - `construir_motivo()`
  - `crear_argumentos()`
  - `determinar_tipo_inicial()`
  - `guardar_incidencias()`
  - `importar()`
  - `insertar_examen()`
  - `insertar_opciones()`
  - `insertar_pregunta()`
  - `limpiar_campo_opcional()`
  - `main()`
  - `obtener_convocatoria_id()`
  - `preparar_pregunta()`
  - `resolver_ruta()`
  - `ruta_incidencias()`
  - `ruta_relativa()`

### `procesos/normalizar_cabeceras.py`

Proceso ejecutable no importado por otros módulos.

- Módulo: `procesos.normalizar_cabeceras`
- Ejecutable: Sí
- Utilizado por: ninguno detectado.
- Utiliza módulos internos: no.
- Funciones:
  - `archivo_init_vacio()`
  - `auditar_script()`
  - `contiene_campo()`
  - `extraer_valor_linea()`
  - `generar_informe()`
  - `leer_texto()`
  - `main()`
  - `obtener_docstring()`
  - `obtener_scripts()`

## ACTIVO

### `core/buscar_documentos_informatica.py`

Es utilizado por otros scripts.

- Módulo: `core.buscar_documentos_informatica`
- Ejecutable: Sí
- Utilizado por:
  - `core/clasificador.py`
- Utiliza:
  - `core.temario`
- Funciones:
  - `buscar_documentos_informatica()`
  - `cargar_documentos()`
  - `main()`
  - `normalizar()`
  - `obtener_documentos_informatica()`
  - `tokenizar()`

### `core/buscar_explicacion.py`

Es utilizado por otros scripts.

- Módulo: `core.buscar_explicacion`
- Ejecutable: No
- Utilizado por:
  - `procesos/generar_explicaciones.py`
- Utiliza módulos internos: no.
- Funciones:
  - `buscar_explicacion()`

### `core/buscar_fragmentos.py`

Es utilizado por otros scripts.

- Módulo: `core.buscar_fragmentos`
- Ejecutable: No
- Utilizado por:
  - `core/clasificador.py`
- Utiliza:
  - `core.temario`
- Funciones:
  - `buscar_fragmentos()`
  - `cargar_fragmentos()`
  - `normalizar()`
  - `obtener_documentos_busqueda()`
  - `tokenizar()`

### `core/clasificador.py`

Es utilizado por otros scripts.

- Módulo: `core.clasificador`
- Ejecutable: No
- Utilizado por:
  - `procesos/clasificar_modelo.py`
  - `procesos/clasificar_pendientes.py`
  - `procesos/clasificar_pregunta.py`
- Utiliza:
  - `core.buscar_documentos_informatica`
  - `core.buscar_fragmentos`
  - `core.normas`
  - `core.openai_api`
  - `core.prompt_seleccionar_documento`
  - `core.prompt_seleccionar_fragmento`
  - `core.temario`
- Funciones:
  - `__init__()`
  - `_aplicar_umbrales()`
  - `_clasificar_informatica()`
  - `_construir_resultado_documento()`
  - `_construir_resultado_fragmento()`
  - `_obtener_asociaciones_fragmento()`
  - `_obtener_documento_seleccionado()`
  - `_obtener_fragmento_seleccionado()`
  - `_validar_opciones()`
  - `_validar_respuesta_correcta()`
  - `_validar_respuesta_ia_documento()`
  - `_validar_respuesta_ia_fragmento()`
  - `clasificar()`
  - `clasificar_directa()`
  - `crear_resultado()`
  - `detectar_articulo()`
  - `detectar_norma_generica()`
  - `detectar_norma_nominada()`
  - `detectar_referencias()`
- Clases:
  - `Clasificador`

### `core/constructor_simulacro.py`

Es utilizado por otros scripts.

- Módulo: `core.constructor_simulacro`
- Ejecutable: Sí
- Utilizado por:
  - `procesos/generar_simulacro.py`
- Utiliza:
  - `core.distribucion_modelo`
  - `core.selector_banco`
- Funciones:
  - `añadir_preguntas()`
  - `completar_desde_otros_temas()`
  - `construir_simulacro()`
  - `prueba()`

### `core/construir_prompt_explicacion.py`

Es utilizado por otros scripts.

- Módulo: `core.construir_prompt_explicacion`
- Ejecutable: No
- Utilizado por:
  - `procesos/generar_explicaciones.py`
- Utiliza módulos internos: no.
- Funciones:
  - `construir_prompt()`

### `core/distribucion_modelo.py`

Es utilizado por otros scripts.

- Módulo: `core.distribucion_modelo`
- Ejecutable: No
- Utilizado por:
  - `core/constructor_simulacro.py`
- Utiliza módulos internos: no.
- Funciones:
  - `obtener_distribucion_modelo()`

### `core/guardar_explicacion.py`

Es utilizado por otros scripts.

- Módulo: `core.guardar_explicacion`
- Ejecutable: No
- Utilizado por:
  - `procesos/generar_explicaciones.py`
- Utiliza módulos internos: no.
- Funciones:
  - `guardar_explicacion()`

### `core/huellas.py`

Es utilizado por otros scripts.

- Módulo: `core.huellas`
- Ejecutable: No
- Utilizado por:
  - `procesos/generar_explicaciones.py`
  - `procesos/importar_json_extraido.py`
- Utiliza módulos internos: no.
- Funciones:
  - `calcular_huella()`

### `core/modelo_simulacro.py`

Es utilizado por otros scripts.

- Módulo: `core.modelo_simulacro`
- Ejecutable: No
- Utilizado por:
  - `core/normalizar_simulacro.py`
- Utiliza módulos internos: no.
- Funciones:
  - `total()`
- Clases:
  - `Opcion`
  - `Pregunta`
  - `Simulacro`

### `core/normalizar_simulacro.py`

Es utilizado por otros scripts.

- Módulo: `core.normalizar_simulacro`
- Ejecutable: No
- Utilizado por:
  - `procesos/generar_pdf.py`
- Utiliza:
  - `core.modelo_simulacro`
- Funciones:
  - `cargar_simulacro()`

### `core/normas.py`

Es utilizado por otros scripts.

- Módulo: `core.normas`
- Ejecutable: No
- Utilizado por:
  - `core/clasificador.py`
  - `core/temario.py`
  - `core/validar_pie.py`
  - `procesos/importar_json_extraido.py`
- Utiliza módulos internos: no.
- Funciones:
  - `alias_desde_codigo()`
  - `alias_especiales()`
  - `cargar_normas()`
  - `codigo_a_prefijo()`
  - `detectar_normas()`
  - `normalizar()`
  - `obtener_norma()`

### `core/obtener_fragmento.py`

Es utilizado por otros scripts.

- Módulo: `core.obtener_fragmento`
- Ejecutable: No
- Utilizado por:
  - `procesos/generar_explicaciones.py`
- Utiliza módulos internos: no.
- Funciones:
  - `obtener_fragmento()`

### `core/openai_api.py`

Es utilizado por otros scripts.

- Módulo: `core.openai_api`
- Ejecutable: No
- Utilizado por:
  - `core/clasificador.py`
  - `procesos/completar_simulacro_ia.py`
  - `procesos/generar_explicaciones.py`
- Utiliza módulos internos: no.
- Funciones:
  - `generar_explicacion_ia()`
  - `registrar_coste()`
  - `seleccionar_fragmento()`
  - `seleccionar_fragmento_json()`

### `core/prompt_seleccionar_documento.py`

Es utilizado por otros scripts.

- Módulo: `core.prompt_seleccionar_documento`
- Ejecutable: No
- Utilizado por:
  - `core/clasificador.py`
- Utiliza módulos internos: no.
- Funciones:
  - `construir_prompt_seleccionar_documento()`

### `core/prompt_seleccionar_fragmento.py`

Es utilizado por otros scripts.

- Módulo: `core.prompt_seleccionar_fragmento`
- Ejecutable: No
- Utilizado por:
  - `core/clasificador.py`
- Utiliza módulos internos: no.
- Funciones:
  - `construir_prompt()`

### `core/render_pdf.py`

Es utilizado por otros scripts.

- Módulo: `core.render_pdf`
- Ejecutable: No
- Utilizado por:
  - `procesos/generar_pdf.py`
- Utiliza módulos internos: no.
- Funciones:
  - `bloque_pregunta()`
  - `generar_pdf()`
  - `limpiar_texto()`

### `core/render_soluciones_pdf.py`

Es utilizado por otros scripts.

- Módulo: `core.render_soluciones_pdf`
- Ejecutable: No
- Utilizado por:
  - `procesos/generar_pdf.py`
- Utiliza módulos internos: no.
- Funciones:
  - `bloque_solucion()`
  - `generar_pdf_soluciones()`
  - `limpiar_texto()`
  - `obtener_opcion_correcta()`

### `core/selector_banco.py`

Es utilizado por otros scripts.

- Módulo: `core.selector_banco`
- Ejecutable: Sí
- Utilizado por:
  - `core/constructor_simulacro.py`
- Utiliza módulos internos: no.
- Funciones:
  - `abrir_conexion()`
  - `cargar_opciones()`
  - `convertir_pregunta()`
  - `prueba()`
  - `seleccionar_preguntas()`

### `core/temario.py`

Es utilizado por otros scripts.

- Módulo: `core.temario`
- Ejecutable: Sí
- Utilizado por:
  - `core/buscar_documentos_informatica.py`
  - `core/buscar_fragmentos.py`
  - `core/clasificador.py`
  - `core/validar_pie.py`
  - `procesos/actualizar_documentos.py`
  - `procesos/clasificar_modelo.py`
  - `procesos/clasificar_pendientes.py`
  - `procesos/clasificar_pregunta.py`
  - `procesos/importar_json_extraido.py`
- Utiliza:
  - `core.normas`
- Funciones:
  - `__init__()`
  - `_cargar_distribucion()`
  - `_cargar_partes()`
  - `_cargar_temario()`
  - `_identificar_norma_documento()`
  - `_obtener_cobertura_documento()`
  - `_obtener_parte_seccion()`
  - `articulo_pertenece()`
  - `es_informatica()`
  - `expandir_articulos()`
  - `main()`
  - `norma_pertenece()`
  - `normalizar()`
  - `normalizar_articulo()`
  - `obtener_asociaciones_articulo()`
  - `obtener_asociaciones_documento()`
  - `obtener_convocatoria()`
  - `obtener_distribucion()`
  - `obtener_documentos()`
  - `obtener_documentos_norma()`
  - `obtener_numero_preguntas()`
  - `obtener_partes()`
  - `obtener_tema()`
  - `obtener_temas()`
  - `obtener_temas_articulo()`
  - `resumen()`
- Clases:
  - `Temario`

### `core/validar_pie.py`

Es utilizado por otros scripts.

- Módulo: `core.validar_pie`
- Ejecutable: No
- Utilizado por:
  - `procesos/importar_json_extraido.py`
- Utiliza:
  - `core.normas`
  - `core.temario`
- Funciones:
  - `crear_resultado()`
  - `validar_pie()`

## INFRAESTRUCTURA

### `core/__init__.py`

Archivo de paquete Python.

- Módulo: `core`
- Ejecutable: No
- Utilizado por:
  - `core/buscar_documentos_informatica.py`
  - `core/buscar_fragmentos.py`
  - `core/clasificador.py`
  - `core/constructor_simulacro.py`
  - `core/normalizar_simulacro.py`
  - `core/temario.py`
  - `core/validar_pie.py`
  - `procesos/actualizar_documentos.py`
  - `procesos/clasificar_modelo.py`
  - `procesos/clasificar_pendientes.py`
  - `procesos/clasificar_pregunta.py`
  - `procesos/completar_simulacro_ia.py`
  - `procesos/generar_explicaciones.py`
  - `procesos/generar_pdf.py`
  - `procesos/generar_simulacro.py`
  - `procesos/importar_json_extraido.py`
- Utiliza módulos internos: no.
