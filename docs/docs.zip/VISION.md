# VISIÓN DEL PROYECTO – OpoCoach

## 1. Objetivo

OpoCoach es una plataforma de apoyo al estudio de oposiciones basada en el temario oficial de una convocatoria.

Su objetivo es proporcionar al opositor un entorno completo de preparación mediante un banco de preguntas de alta calidad, simulacros realistas y herramientas de apoyo construidas exclusivamente a partir de la documentación oficial de la convocatoria.

La aplicación está diseñada para ser reutilizable en cualquier oposición basada en un temario documental, sin modificar su arquitectura.

---

## 2. Principios

### La convocatoria es la unidad de trabajo

Toda la información, procesos y resultados pertenecen a una convocatoria concreta.

### El temario define el ámbito

El temario determina qué normas, artículos y documentos forman parte de la convocatoria y cómo se organizan en temas.

### El corpus documental es la única fuente de conocimiento

Toda pregunta, explicación o respuesta deberá fundamentarse exclusivamente en la documentación incorporada a la convocatoria.

### La calidad prevalece sobre la cantidad

El objetivo no es generar muchas preguntas, sino construir un banco de preguntas con calidad suficiente para formar parte de un examen oficial.

### El banco de preguntas es el núcleo del sistema

Todas las funcionalidades reutilizan el mismo banco de preguntas:

- Simulacros.
- Tests.
- Corrección.
- Informes.
- Futuras herramientas de estudio.

### La Inteligencia Artificial es una herramienta

La IA participa únicamente en aquellos procesos para los que aporta valor, utilizando siempre la información proporcionada por OpoCoach y bajo las reglas definidas por la aplicación.

---

## 3. Arquitectura funcional

```text
Convocatoria
      │
      ▼
Temario
      │
      ▼
Corpus documental
      │
      ▼
Fragmentación e indexación
      │
      ▼
Generación / Importación de preguntas
      │
      ▼
Validación
      │
      ▼
Clasificación
      │
      ▼
Banco de preguntas
      │
      ├── Simulacros
      ├── Tests
      ├── Corrección
      ├── Informes IA
      └── Tutor (futuro)
```

Cada etapa reutiliza el resultado de la anterior. Todas las funcionalidades trabajan sobre el banco de preguntas de la convocatoria.

---

## 4. Estado del proyecto

Actualmente se encuentran implementados:

- Gestión de convocatorias.
- Gestión del temario.
- Importación del corpus documental.
- Fragmentación e indexación.
- Generación de preguntas mediante IA.
- Refinamiento de preguntas.
- Validación según el temario.
- Clasificación por parte, tema y tipo.
- Importación de exámenes oficiales.
- Banco de preguntas por convocatoria.
- Generación de simulacros.
- Corrección automática.
- Informe personalizado mediante IA.

---

## 5. Evolución

Las siguientes líneas de desarrollo previstas son:

- Procesos de mantenimiento offline.
- Importación automática de preguntas desde exámenes en PDF.
- Herramientas avanzadas de entrenamiento.
- Tutor especializado en la convocatoria.
- Nuevas herramientas de apoyo al opositor.

Las nuevas funcionalidades deberán integrarse reutilizando la arquitectura existente y preservando la compatibilidad con el banco de preguntas.

---

## 6. Criterios de desarrollo

Durante el desarrollo del proyecto se seguirán los siguientes criterios:

- Priorizar la simplicidad.
- Evitar complejidad innecesaria.
- Mantener una única responsabilidad por módulo.
- Evitar la duplicación de información.
- Garantizar la trazabilidad desde cada pregunta hasta su origen documental.
- Incorporar únicamente funcionalidades que aporten valor al opositor.
- Mantener la documentación alineada con el estado real del proyecto.