# ARQUITECTURA DE LA BASE DE DATOS

**Versión:** 1.0

---

# Objetivo

Describir la organización general de la base de datos y la relación entre sus principales bloques funcionales.

La arquitectura está diseñada para soportar múltiples convocatorias reutilizando una única estructura de datos.

---

# Principios

- Una única base de datos.
- Cada convocatoria constituye una unidad independiente.
- Evitar duplicidad de información.
- Mantener la trazabilidad completa de cada pregunta.
- Preservar la integridad referencial.

---

# Estructura funcional

## Convocatorias

Define las convocatorias gestionadas por la aplicación y su configuración.

---

## Temario

Contiene la estructura del temario de cada convocatoria:

- Partes.
- Temas.
- Normas.
- Artículos o rangos de artículos asociados.

---

## Corpus documental

Almacena los documentos oficiales de cada convocatoria y su relación con el temario.

---

## Fragmentos

Cada documento se divide en fragmentos que constituyen la base documental utilizada por los distintos procesos de IA y búsqueda.

---

## Preguntas importadas

Repositorio permanente de todas las preguntas procedentes de exámenes oficiales.

Cada pregunta conserva únicamente su información objetiva:

- Procedencia.
- Norma.
- Artículo.
- Respuesta oficial.
- Metadatos de origen.

---

## Banco de preguntas

Contiene las preguntas válidas para una convocatoria concreta.

Cada incorporación al banco es consecuencia del proceso de validación y clasificación.

---

## Simulacros

Almacena los simulacros generados y su composición.

---

## Resultados

Almacena los intentos realizados por los opositores y sus resultados.

---

# Flujo general

```text
Convocatoria
      │
      ▼
Temario
      │
      ▼
Corpus documental
      │
      ▼
Fragmentos
      │
      ├── Generación IA
      ├── Clasificación
      └── Validación
              │
              ▼
Preguntas importadas
              │
              ▼
Banco de preguntas
              │
      ┌───────┼────────┐
      ▼       ▼        ▼
 Simulacros Tests Corrección
                     │
                     ▼
                Informe IA
```

---

# Evolución

La arquitectura permite incorporar nuevas convocatorias y nuevas funcionalidades sin modificar el modelo general de la base de datos.

Los cambios en el temario de una convocatoria deberán resolverse mediante procesos de mantenimiento y revalidación del banco de preguntas, sin alterar la información objetiva de las preguntas importadas.