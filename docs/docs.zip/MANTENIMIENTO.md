# MANTENIMIENTO

## Objetivo

Reunir los procesos de mantenimiento del sistema que pueden ejecutarse de forma independiente del uso normal de la aplicación.

Todos los procesos deberán ser idempotentes siempre que sea posible.

---

# Documentación

- Importación del corpus documental.
- Importación de preguntas.
- Importación de exámenes.
- Regeneración de índices.
- Auditorías de consistencia.

---

# Banco de preguntas

- Revalidación del banco.
- Reclasificación de preguntas.
- Eliminación de duplicados.
- Regeneración de estadísticas.
- Recalcular distribución por temas.

---

# Cambios en el temario

Cuando se modifique la asignación de normas o artículos a temas:

- actualizar el temario;
- localizar las preguntas afectadas;
- revalidar las preguntas;
- reclasificar las preguntas;
- actualizar el banco de la convocatoria;
- recalcular las estadísticas.

Las preguntas importadas conservarán siempre su información objetiva de origen. El mantenimiento únicamente modificará su relación con el banco de la convocatoria.

---

# Auditorías

Procesos de comprobación de:

- Integridad de documentos.
- Integridad de fragmentos.
- Integridad del banco.
- Cobertura del temario.
- Consistencia de simulacros.

---

# Objetivo

Todos los procesos de mantenimiento deberán poder ejecutarse repetidamente sin producir inconsistencias ni duplicar información.