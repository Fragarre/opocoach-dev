# OpoCoach

**Versión:** 0.2

**Documento:** Convenciones de desarrollo

---

# 1. Objetivo

Establecer las normas de diseño y desarrollo del proyecto para mantener una arquitectura homogénea y facilitar su mantenimiento.

---

# 2. Arquitectura

- La aplicación es multiconvocatoria.
- La convocatoria es la unidad funcional de la aplicación.
- Cada convocatoria se identifica mediante un código `cfg`.
- Todas las convocatorias utilizan la misma arquitectura.

---

# 3. Banco de preguntas

- Existe un único banco de preguntas por convocatoria.
- El banco contiene únicamente preguntas válidas para esa convocatoria.
- El origen de una pregunta no condiciona su utilización.
- El origen se conserva únicamente con fines informativos y estadísticos.

---

# 4. Scripts

- Cada script tendrá una única responsabilidad.
- Los procesos ejecutables se ubicarán en `procesos`.
- Los módulos reutilizables se ubicarán en `core`.
- Todos los scripts deberán incluir la cabecera estándar del proyecto.

---

# 5. Base de datos

- Toda modificación de la base de datos se realizará mediante procesos específicos.
- Las relaciones se mantendrán mediante claves foráneas.
- No se duplicará información salvo por motivos justificados de rendimiento.

---

# 6. Inteligencia Artificial

- La IA es una herramienta de apoyo.
- Ninguna pregunta se incorporará al banco sin superar los procesos de validación.
- Las explicaciones se generarán únicamente utilizando documentación perteneciente a la convocatoria correspondiente.

---

# 7. Documentación

- Toda modificación relevante deberá reflejarse en la documentación.
- La documentación describirá la arquitectura y la funcionalidad, no la implementación.
- Las decisiones de arquitectura deberán registrarse en la documentación correspondiente.

---

# 8. Código

- Utilizar nombres descriptivos.
- Mantener funciones pequeñas y especializadas.
- Evitar código duplicado.
- Evitar dependencias innecesarias.
- Mantener un formato homogéneo en todo el proyecto.

---

# 9. Evolución

Las nuevas funcionalidades deberán integrarse respetando estas convenciones.

Las modificaciones de arquitectura deberán documentarse antes de considerarse consolidadas.