# OpoCoach

Documentación del proyecto.

## Índice

00. FUNCIONALIDAD.md
    Qué hace la aplicación.

01. ESTRUCTURA_PROYECTO.md
    Organización del proyecto.

02. CONVENCIONES.md
    Normas de desarrollo.

03. ARQUITECTURA_BD.md
    Diseño de la base de datos.

04. SCRIPTS.md
    Inventario de scripts.

05. ESTADO.md
    Estado actual del proyecto.

06. HISTORIAL_VERSIONES.md
    Historial de versiones.

## Versión con preguntas masivas

git push -u origin v1.0.0