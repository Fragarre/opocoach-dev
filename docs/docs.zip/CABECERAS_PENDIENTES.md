# OpoCoach

**Documento:** Auditoría de cabeceras

## Resumen

| Estado | Cantidad |
|---|---:|
| Correctas | 38 |
| Incompletas | 0 |
| Sin cabecera | 0 |
| Error de sintaxis | 0 |
| Total | 38 |

## Cabeceras correctas

- `core/__init__.py`
- `core/buscar_documentos_informatica.py`
- `core/buscar_explicacion.py`
- `core/buscar_fragmentos.py`
- `core/clasificador.py`
- `core/constructor_simulacro.py`
- `core/construir_prompt_explicacion.py`
- `core/distribucion_modelo.py`
- `core/guardar_explicacion.py`
- `core/huellas.py`
- `core/modelo_simulacro.py`
- `core/normalizar_simulacro.py`
- `core/normas.py`
- `core/obtener_fragmento.py`
- `core/openai_api.py`
- `core/prompt_seleccionar_documento.py`
- `core/prompt_seleccionar_fragmento.py`
- `core/render_pdf.py`
- `core/render_soluciones_pdf.py`
- `core/selector_banco.py`
- `core/temario.py`
- `core/validar_pie.py`
- `procesos/actualizar_documentos.py`
- `procesos/auditar_scripts.py`
- `procesos/calcular_distribucion_modelo.py`
- `procesos/clasificar_modelo.py`
- `procesos/clasificar_pendientes.py`
- `procesos/clasificar_pregunta.py`
- `procesos/clasificar_tipo_pregunta.py`
- `procesos/completar_simulacro_ia.py`
- `procesos/documentar_scripts.py`
- `procesos/exportar_simulacro_html.py`
- `procesos/extraer_pdf_imagenes.py`
- `procesos/generar_explicaciones.py`
- `procesos/generar_pdf.py`
- `procesos/generar_simulacro.py`
- `procesos/importar_json_extraido.py`
- `procesos/normalizar_cabeceras.py`
