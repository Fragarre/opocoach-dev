# OpoCoach

**Versión:** 1.0

**Documento:** Funcionalidad general

**Última revisión:** 2026-07-14

## 1. Objetivo

OpoCoach es una aplicación destinada a la preparación de oposiciones mediante la generación automática de simulacros de examen de alta calidad.

La aplicación está diseñada para gestionar cualquier número de convocatorias de oposición de forma independiente. Cada convocatoria se define mediante una configuración (`cfg`) que determina el temario, la estructura del examen y el resto de parámetros específicos.

El objetivo principal de OpoCoach es construir, mantener y explotar un banco de preguntas de alta calidad para cada convocatoria, permitiendo generar simulacros realistas, equilibrados y ajustados al temario oficial.

La inteligencia artificial se utiliza como herramienta de apoyo en los procesos de extracción, validación, clasificación y generación de explicaciones, pero todas las preguntas incorporadas al banco deben superar previamente los procesos automáticos definidos para la convocatoria correspondiente.

---

## 2. Convocatorias

La unidad de trabajo de OpoCoach es la convocatoria.

Cada convocatoria constituye un entorno independiente que contiene toda la información necesaria para la preparación de esa oposición.

Una convocatoria define, entre otros elementos:

- Código identificador (`cfg`).
- Temario.
- Partes del examen.
- Temas.
- Distribución del examen.
- Normativa aplicable.
- Banco de preguntas.
- Simulacros generados.
- Explicaciones.

La incorporación de nuevas convocatorias no requiere modificar la aplicación, sino únicamente añadir su configuración y la documentación correspondiente.

---

## 3. Banco de preguntas

Cada convocatoria dispone de un único banco de preguntas.

El banco no representa el origen de las preguntas, sino el conjunto de preguntas válidas para esa convocatoria.

Las preguntas pueden proceder de distintas fuentes:

- Exámenes oficiales.
- Exámenes de apoyo.
- Tests.
- Cuestionarios.
- Otras fuentes que puedan incorporarse en el futuro.

Una vez importadas, todas las preguntas son sometidas al mismo proceso de extracción, validación y clasificación.

Solo las preguntas que pertenecen al temario de la convocatoria pasan a formar parte del banco.

El origen de una pregunta se conserva únicamente como información histórica y estadística, sin afectar a su utilización posterior.

---

## 4. Flujo funcional

Todas las convocatorias siguen el mismo flujo de trabajo.

### 4.1 Definición de la convocatoria

Cada convocatoria se define mediante un fichero de configuración (`cfg`) que determina:

- Temario.
- Partes del examen.
- Temas.
- Distribución oficial del examen.
- Normativa aplicable.
- Parámetros específicos.

---

### 4.2 Incorporación del temario

Los documentos oficiales del temario se incorporan a la base de datos.

Cada documento queda asociado a:

- convocatoria;
- norma;
- artículos comprendidos;
- tema;
- parte del temario.

---

### 4.3 Fragmentación documental

Los documentos se fragmentan en unidades homogéneas.

Cada fragmento mantiene la relación con:

- documento;
- convocatoria;
- norma;
- artículo;
- tema;
- parte.

La fragmentación constituye la base documental utilizada posteriormente por la aplicación.

---

### 4.4 Indexación

Los fragmentos se indexan para permitir su recuperación posterior mediante búsquedas semánticas.

Este índice constituye la base documental utilizada por los distintos procesos de inteligencia artificial.

---

### 4.5 Incorporación de preguntas

Las preguntas pueden proceder de diferentes fuentes.

Durante su incorporación se extraen automáticamente:

- enunciado;
- opciones;
- respuesta correcta;
- referencia normativa;
- información de origen.

---

### 4.6 Validación

Cada pregunta es validada utilizando exclusivamente la referencia normativa obtenida durante la extracción.

El resultado puede ser:

- VALIDADA
- A_REVISAR
- RECHAZADA

Solo las preguntas válidas pueden incorporarse al banco.

---

### 4.7 Clasificación

Las preguntas validadas se clasifican automáticamente según:

- parte del temario;
- tema;
- tipo de pregunta:
  - GENERAL;
  - ESPECIAL_TEORIA;
  - ESPECIAL_PRACTICA;
  - ESPECIAL_INFORMATICA.

---

### 4.8 Banco de preguntas

Las preguntas validadas pasan a formar parte del banco de la convocatoria.

Las preguntas rechazadas o pendientes de revisión permanecen almacenadas únicamente para tareas de auditoría y revisión.

---

### 4.9 Generación de simulacros

Los simulacros se construyen exclusivamente utilizando preguntas del banco de la convocatoria.

La generación respeta:

- estructura oficial;
- distribución por partes;
- distribución por temas;
- equilibrio de respuestas;
- nivel de dificultad;
- longitud.

---

### 4.10 Generación de explicaciones

Las explicaciones se generan utilizando únicamente los fragmentos documentales pertenecientes a la convocatoria correspondiente.

Cada explicación queda asociada a la pregunta correspondiente.

---

### 4.11 Exportación

Los simulacros pueden exportarse en distintos formatos.

Actualmente:

- HTML;
- PDF;
- PDF con soluciones.

---

## 5. Principios de diseño

El desarrollo de OpoCoach se basa en los siguientes principios:

### Independencia de las convocatorias

Cada convocatoria constituye una unidad independiente de trabajo.

La incorporación de nuevas convocatorias no debe requerir modificaciones en el código de la aplicación.

---

### Banco único por convocatoria

Cada convocatoria dispone de un único banco de preguntas.

Todas las preguntas válidas, independientemente de su procedencia, forman parte del mismo banco.

---

### Validación previa obligatoria

Ninguna pregunta puede incorporarse al banco sin superar previamente los procesos de validación establecidos para la convocatoria.

---

### Trazabilidad

Toda pregunta conserva la información necesaria para conocer:

- origen;
- convocatoria;
- norma;
- artículo;
- tema;
- parte;
- proceso de validación.

---

### Automatización

Todos los procesos repetitivos deben poder ejecutarse automáticamente.

Las intervenciones manuales deben limitarse a tareas de revisión y auditoría.

---

### Modularidad

Cada proceso constituye un módulo independiente.

Siempre que sea posible, los módulos deben poder reutilizarse en otras convocatorias.

---

## 6. Modelo de datos

La información gestionada por OpoCoach puede agruparse en los siguientes bloques:

- Convocatorias.
- Temarios.
- Documentación.
- Fragmentos documentales.
- Índices.
- Banco de preguntas.
- Simulacros.
- Explicaciones.

Las relaciones entre estos elementos permiten mantener completamente separadas las distintas convocatorias gestionadas por la aplicación.

---

## 7. Estado actual del proyecto

En la versión actual de OpoCoach se encuentran operativos los siguientes módulos:

- Gestión de convocatorias.
- Gestión del temario.
- Importación de documentación.
- Fragmentación documental.
- Indexación de fragmentos.
- Incorporación de preguntas desde distintas fuentes.
- Extracción automática de preguntas.
- Validación automática mediante referencia normativa.
- Clasificación temática.
- Clasificación por tipo de pregunta.
- Banco de preguntas.
- Detección de preguntas duplicadas.
- Generación de simulacros.
- Generación de explicaciones.
- Exportación de simulacros.

La arquitectura de la aplicación permite ampliar cualquiera de estos módulos sin afectar al resto del sistema.

---

## 8. Evolución prevista

La evolución futura de OpoCoach contempla, entre otras, las siguientes líneas de desarrollo:

- Incorporación de nuevas convocatorias.
- Ampliación del banco de preguntas.
- Nuevos formatos de importación.
- Mejora de las herramientas de auditoría.
- Optimización del rendimiento.
- Incorporación de nuevas funcionalidades de apoyo al opositor.

## Resumen de funcionalidades detallada.
- Opción de simulacro PDF / simulacro on-line.
  - Para la obtención de los simulacros o ejercicios de test suministrados, en cada convoctoria se partira de un banco de preguntas.
  - El banco de preguntas pertenece a cada convocatoría. Las preguntas que se importen. independientemente de la fuente,  todas ellas, se guardarán con indicación de artículo y norma a la que pertenecen. Ademas se indicará la fuente de procedencia en cuanto a puesto: A1, A2, C1, C2 y los que puedan establcerse en el futuro.
  - El banco de preguntas es único por convocatoria pero las preguntas importadas son comunes y podrán ser incorporadas al banco correspondiente en función de un proceso de validación.
  - Las preguntas serán seleccionadas y clasificadas en el Banco de preguntas de cada convocatoria según el temario de cada convocatoria, que es quien define la convocatoria.
    - Clasificación en el banco. Cada tema del temario, contiene un o varios artículos de una o varias normas que definen el tema. El artículo y norma de la pregunta en el prceso de validación,definirá si se considera válida (entra en el banco) y a que tema pertenece. El temario podrá estar dividido además en partes, en ese caso la pregunta en el banco conservará la parte del temario a que pertenece, que quedrá definida por el número de tema u otro mecanismo si existe que se especificará en las normas de cada convocatoria. El banco mantendrá además la informaciçon del Puesto al que el Examen, documento o test de donde se importó, pertenecia. Si el la norma de una pregunta no pertenece al temario de la convocatoría o perteneciendo a la convocatoria no pertenece el artículo a que se refiere, quedará automáticmante rechazada. Es decir no se incorpora al banco. Aceptada o rechazada, no són clasificaciones son criterios para incluir o no una pregunta en el banco. Si no puede decidirse incluso con el apoyo de la IA, si la pregunta es aceptada o rechazada, se pedirá al operador que decida en el proceso de importación si se acepta o no.

- Elegir nivel de dificultad. Facil provinientes de niveles inferiores, por ejemplo, para convocatoria C1, facil preguntas provinientes  de C2, dificil preguntas provinientes de A2 o A1. Para convocatorias A2, facil preguntas provinientes de C1 o C2, dificil A1, para A1 faciles, pero no dificiles (no hay mayor grado)
- Calficación de resultados, siguiendo normas de puntos y penalizaciones. Adecuación de calificación a puntos. Ejemlo examen da 40 punros, un 10 en la calificación son 40 puntos.
- porcentajes de respondidas, sobre total, acertadas falladas sobre total y acertadas falladas sobre respondidas.
- recomendaciones de nivel de riesgo a asumir. En cada convocatoría las falladas penalizan del modo descrito en la convocatoria. Nivel de riesgo asumible, si tengo segurodad x% de acertar, cuantas puedo fallar?. Cálculos de este tipo en función de resultados.
- Comentarios en función de los resultados de puntos-fuertes, puntos-débiles. Recomendaciones de repaso.
- Opción de TEST bajo de manda por PARTES TEMARIO, o temas TEMARIO. Formato PDF, formato interactivo
- Consulta de dudas sobre teoría de la oposición. Respuestas basadas exclusivamente en el análisis de datos de cada convocatoria.
- Interface Streamlit fornt end backend para la aplicación con mecanismo usuario - clave. En principio versión gratuita. Base de datos residente en Streamlit si es posible. Las actualizaciones de bases de datos de convocatorias y preguntas, se realizarán of line desde portatil local y mecanismo de actualización db en Streamlite.

La arquitectura actual ha sido diseñada para facilitar esta evolución manteniendo la independencia entre convocatorias y la reutilización de los componentes comunes.

