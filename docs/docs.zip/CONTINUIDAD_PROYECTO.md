ORDEN DE LECTURA OBLIGATORIO PARA RETOMAR EL PROYECTO

1. 00_CONTINUIDAD_PROYECTO.md
2. FUNCIONALIDAD.md
3. CONVENCIONES.md
4. ARQUITECTURA_BD.md
5. ESTADO.md
6. SCRIPTS.md

# OpoCoach

# CONTINUIDAD DEL PROYECTO

Última actualización: 17/07/2026

---

# Estado general

El proyecto se encuentra en una fase funcional.

Toda la arquitectura principal está consolidada.

NO deben proponerse cambios de arquitectura salvo error grave.

La prioridad absoluta es finalizar la primera versión funcional de la aplicación Streamlit.

---

# Arquitectura consolidada

La aplicación es MULTICONVOCATORIA.

La unidad funcional es la convocatoria.

Cada convocatoria dispone de:

- temario;
- documentos;
- fragmentos;
- banco de preguntas;
- simulacros.

No existen desarrollos específicos por convocatoria.

---

# Banco de preguntas

Existe un único banco por convocatoria.

Todas las preguntas válidas terminan en el banco independientemente de su origen.

El origen únicamente tiene valor estadístico.

---

# Importación

Actualmente existen tres procesos independientes.

1. Exámenes oficiales y de apoyo.

2. PDFs con preguntas en imágenes.

3. PDFs de informática sin respuestas.

Todos terminan incorporando preguntas al banco mediante los procesos de validación correspondientes.

---

# Simulacros

El simulacro se genera desde:

Banco
↓

Constructor
↓

Objeto Simulacro
↓

JSON

↓

PDF examen

↓

PDF solucionario

↓

Streamlit

Todos utilizan exactamente el mismo objeto Simulacro.

No debe duplicarse información.

---

# Numeración

Los simulacros utilizan numeración secuencial por convocatoria.

Ejemplo:

SIM_0018_C1_01_17072026

---

# Estado actual de Streamlit

Funciona:

✔ Selección de convocatoria

✔ Generación del simulacro

✔ Descarga PDF examen

✔ Descarga PDF solucionario

✔ session_state

✔ Identificador del simulacro

✔ Plantilla interactiva de 110 respuestas

Pendiente:

Corrección automática.

Estadísticas.

---

# Documentación

La documentación se considera prácticamente estabilizada.

Siempre que cambie una decisión de arquitectura deberá actualizarse antes de cambiar de hilo.

---

# Scripts principales

core/

- constructor_simulacro.py
Construcción del simulacro.

- selector_banco.py
Selección de preguntas.

- distribucion_modelo.py
Distribución oficial.

- render_pdf.py
PDF examen.

- render_soluciones_pdf.py
PDF solucionario.

- modelo_simulacro.py
Objeto Simulacro.

- normalizar_simulacro.py
Conversión JSON ⇄ objeto.

procesos/

- generar_simulacro.py
Proceso principal utilizado por Streamlit.

- generar_explicaciones.py
Generación IA.

- generar_pdf.py
Generación de PDFs.

- importar_json_extraido.py
Importación desde PDFs de imágenes.

- actualizar_documentos.py
Importación documental.

---

# Principios de desarrollo

NO modificar arquitectura sin necesidad.

NO refactorizar por estética.

NO optimizar prematuramente.

Cambios pequeños.

Probar cada cambio.

Scripts completos cuando afecten varias partes.

Respuestas breves.

Nunca asumir información que no esté confirmada.

---

# Próximo objetivo

Finalizar la corrección interactiva.

El siguiente desarrollo previsto es:

1. Corrección automática.

2. Mostrar preguntas falladas.

3. Mostrar explicación.

4. Calcular nota oficial.

5. Estadísticas del opositor.

NO comenzar nuevas funcionalidades hasta terminar este bloque.

# Siguiente fase: mantenimiento offline

Una vez finalizada la corrección interactiva del simulacro, la siguiente fase del proyecto será construir el mantenimiento offline.

La prioridad será consolidar los procesos existentes sin modificar innecesariamente la arquitectura.

## 1. Menú de mantenimiento

Crear un menú sencillo para ejecutar los procesos offline de mantenimiento.

Debe permitir gestionar, como mínimo:

- `data_examenes`
- `data_preguntas`
- `data_informatica`
- nuevas convocatorias
- auditoría de duplicados
- revisión del banco

Los archivos se incorporarán manualmente a las carpetas correspondientes.

El menú únicamente coordinará y facilitará la ejecución de los procesos existentes.

## 2. Importaciones idempotentes

Todos los procesos de importación deberán ser idempotentes.

Ejecutar varias veces el mismo proceso sobre los mismos archivos no debe:

- duplicar exámenes;
- duplicar preguntas;
- duplicar opciones;
- duplicar relaciones;
- duplicar preguntas en el banco;
- modificar incorrectamente registros ya procesados.

Antes de insertar información deberá comprobarse si el archivo, examen o pregunta ya ha sido procesado.

## 3. Consolidación de los tres procesos de importación

### data_examenes

Debe gestionar:

- exámenes modelo;
- exámenes de apoyo;
- preguntas;
- opciones;
- bloque de origen;
- puesto de procedencia;
- validación;
- clasificación;
- incorporación al banco únicamente de las preguntas válidas.

### data_preguntas

Debe gestionar PDFs con una pregunta por página.

Flujo previsto:

1. extracción;
2. importación neutral;
3. validación por convocatoria;
4. clasificación;
5. incorporación al banco de las preguntas validadas.

La referencia del pie de página tendrá prioridad para determinar norma y artículo.

### data_informatica

Debe gestionar PDFs de informática sin respuestas.

Flujo previsto:

1. extracción de preguntas;
2. generación de opciones y respuesta correcta mediante IA;
3. clasificación documental y temática;
4. validación;
5. incorporación al banco únicamente de las preguntas válidas.

## 4. Revisión del flujo completo

Debe revisarse que todos los procesos cumplen el mismo principio:

Pregunta importada
↓

Validación para una convocatoria
↓

Clasificación por parte, tema y tipo
↓

Entrada en el banco únicamente si está validada

Las preguntas rechazadas o pendientes no deben incorporarse al banco.

No se debe asumir que este flujo funciona correctamente en todos los procesos sin revisarlo.

## 5. Mantenimiento de duplicados

Debe existir un proceso específico para detectar y eliminar duplicados.

### Preguntas importadas

Se considerará duplicada una pregunta cuando coincidan exactamente:

- el enunciado;
- las opciones A, B, C y D.

Debe revisarse también la respuesta correcta antes de eliminar registros.

Si dos registros idénticos tienen respuestas correctas diferentes, deberán pasar a revisión manual.

### Banco de cada convocatoria

Debe realizarse la misma comprobación dentro de cada banco.

No debe eliminarse automáticamente una pregunta únicamente porque proceda de otra fuente.

El origen debe conservarse cuando sea posible.

Antes de eliminar duplicados deberán revisarse las relaciones con:

- opciones;
- evaluaciones por convocatoria;
- banco;
- explicaciones;
- simulacros;
- cualquier otra tabla dependiente.

El proceso deberá ser auditable y generar un informe antes de aplicar cambios.

## 6. Alta de nuevas convocatorias

Debe desarrollarse un proceso guiado para incorporar nuevas convocatorias.

El flujo incluirá:

1. crear el nuevo CFG;
2. registrar la convocatoria;
3. definir partes y temas;
4. importar leyes, normas y manuales;
5. asociar documentos al temario;
6. fragmentar e indexar la documentación;
7. definir la estructura y distribución del examen;
8. crear el banco de la convocatoria;
9. evaluar las preguntas importadas existentes para la nueva convocatoria;
10. incorporar al banco únicamente las preguntas validadas.

La incorporación de una nueva convocatoria no debe requerir modificar el código general de la aplicación.

## 7. Orden de trabajo previsto

1. Terminar la corrección interactiva.
2. Auditar el estado real de los tres procesos de importación.
3. Documentar entradas, salidas y tablas afectadas.
4. Garantizar la idempotencia.
5. Crear el proceso de detección de duplicados.
6. Crear el menú de mantenimiento offline.
7. Desarrollar el alta guiada de nuevas convocatorias.
8. Probar el flujo completo con una convocatoria de prueba.
